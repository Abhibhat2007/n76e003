#include "Arduino.h"

void initVariant(void)
{
    /* board specific initialization */
}