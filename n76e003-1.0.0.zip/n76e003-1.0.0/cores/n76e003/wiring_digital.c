#include "Arduino.h"

/* Example register definition for P1.2 */
volatile unsigned char P1;

/* simple bit mask */
#define BIT2 0x04

void pinMode(uint8_t pin, uint8_t mode)
{
    /* simplified example */
    (void)pin;
    (void)mode;
}

void digitalWrite(uint8_t pin, uint8_t value)
{
    if(pin == 12)
    {
        if(value)
            P1 |= BIT2;
        else
            P1 &= ~BIT2;
    }
}