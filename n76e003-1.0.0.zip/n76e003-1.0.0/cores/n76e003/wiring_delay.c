#include "Arduino.h"

void delay(unsigned int ms)
{
    unsigned int i;
    unsigned int j;

    for(i=0;i<ms;i++)
        for(j=0;j<120;j++);
}