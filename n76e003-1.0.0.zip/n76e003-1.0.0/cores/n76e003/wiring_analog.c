#include "Arduino.h"

int analogRead(uint8_t pin)
{
    (void)pin;
    return 0;
}