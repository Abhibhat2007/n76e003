#ifndef Arduino_h
#define Arduino_h

#include <stdint.h>

#define HIGH 1
#define LOW 0

#define INPUT 0
#define OUTPUT 1

void pinMode(uint8_t pin, uint8_t mode);
void digitalWrite(uint8_t pin, uint8_t value);
void delay(unsigned int ms);

#endif