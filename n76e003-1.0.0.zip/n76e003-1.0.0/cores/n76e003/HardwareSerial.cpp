#include "Arduino.h"

class HardwareSerial
{
public:
    void begin(unsigned long baud)
    {
        (void)baud;
    }

    void print(const char* msg)
    {
        (void)msg;
    }
};

HardwareSerial Serial;